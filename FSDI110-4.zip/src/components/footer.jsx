import './footer.css';

const Footer = () => {
    return (<div className="footer">
        <h6>@All rights reserved JandL Designs 2022</h6></div>
    )
  };
  
  export default Footer;
  //adding styling, have to have a CSS